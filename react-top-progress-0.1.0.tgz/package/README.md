# react-top-progress

![Demo of react-top-progress](demo_react_top_progress.png)

**[👉 View Live Demo](https://react-test-progress.vercel.app/)**

A lightweight, modern, and performant top loading progress bar for React.

Perfect for Next.js App Router, Vite, and standard single-page applications.

## Features

- **0 dependencies**: Tiny footprint (~1kb gzipped).
- **Realistic loading feel**: Increments incrementally like real network requests.
- **Premium DX**: Controlled programmatically with simple `startProgress` / `finishProgress` API.
- **Gradient & Glow Support**: Fully customizable colors, shadow pegs, and effects.
- **Performant**: Uses `transform` hardware acceleration and `cubic-bezier` transitions.
- **TypeScript ready**: Full types included.
- **React 18+ & Next.js ready**: Contains `"use client"` where necessary.

## Installation

```bash
npm install react-top-progress
```

**Or using yarn / pnpm / bun:**

```bash
yarn add react-top-progress
pnpm add react-top-progress
bun add react-top-progress
```

## Quick Start

### 1. Add the component to your root layout/app

At the top level of your application (like Next.js `app/layout.tsx` or Vite `src/App.tsx`), render the `<TopProgress />` component.

```tsx
import { TopProgress } from "react-top-progress";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <TopProgress />
        {children}
      </body>
    </html>
  );
}
```

### 2. Control it programmatically

Import the API from anywhere in your app to trigger the progress bar manually!

```tsx
import { startProgress, finishProgress } from "react-top-progress";

async function handleAction() {
  startProgress();
  try {
    await someHeavyTask();
  } finally {
    finishProgress();
  }
}
```

### 3. The `withProgress` Utility

For an even better Developer Experience, simply wrap your promises securely with `withProgress`!

```tsx
import { withProgress } from "react-top-progress";

async function handleFetch() {
  const data = await withProgress(fetch("/api/data"));
  console.log(data);
}
```

## Customization API

The `TopProgress` component accepts the following props:

| Prop        | Type      | Default     | Description                                                                                                  |
| ----------- | --------- | ----------- | ------------------------------------------------------------------------------------------------------------ |
| `color`     | `string`  | `"#29D"`    | Flat hex color or `linear-gradient(...)` function string                                                     |
| `height`    | `number`  | `3`         | Height of the progress bar in pixels                                                                         |
| `showGlow`  | `boolean` | `true`      | Whether to display the premium box-shadow drop-glow and trailing peg                                         |
| `glowColor` | `string`  | `undefined` | Optionally override the color of the glow effect. By default, it infers realistically from your main `color` |
| `zIndex`    | `number`  | `9999`      | The z-index stacking context level.                                                                          |

## Credits & Inspiration

Designed for the modern web. Inspired by the classic `nprogress` and Next.js' `nextjs-toploader`. Ideal when you need explicit control without relying solely on framework routing events.

## License

MIT
